const repos = [
  { name: "FlashCards", url: "https://github.com/romaindenis1/FlashCards" },
];

const defaultRepoUrl = "https://github.com/romaindenis1/FlashCards";
const defaultAuthToken = "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";
